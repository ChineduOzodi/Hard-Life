﻿using UnityEngine;
using System.Collections;
using System;

public class TreeModel : PlantModel {

    internal int maxStick;
    internal int maxWood;
    
}

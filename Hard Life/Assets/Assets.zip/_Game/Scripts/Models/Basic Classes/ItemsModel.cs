﻿using UnityEngine;

public class ItemsModel : BaseObjectModel
{
    
    
    internal int stackLimit = 1;
    internal int amount = 1;
    bool stackable = false;

    
}
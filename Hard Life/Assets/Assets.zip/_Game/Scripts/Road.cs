﻿using UnityEngine;

public class RoadModel : BaseObjectModel
{

}
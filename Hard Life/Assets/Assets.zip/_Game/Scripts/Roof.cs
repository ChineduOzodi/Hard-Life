﻿using UnityEngine;

public class RoofModel : ItemsModel
{

}
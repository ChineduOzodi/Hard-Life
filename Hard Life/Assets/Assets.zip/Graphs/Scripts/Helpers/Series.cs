﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class Series {

    internal List<Vector2> points;

    string xAxis;
    string yAxis;

    string name;

}

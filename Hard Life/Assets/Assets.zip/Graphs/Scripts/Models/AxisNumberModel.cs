﻿using UnityEngine;
using System.Collections;
using CodeControl;


public class AxisNumberModel : Model {

    public string numberText;


}

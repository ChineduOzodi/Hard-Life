﻿using UnityEngine;
using System.Collections;
using CodeControl;
using System.Collections.Generic;

public class LineGraphModel : Model
{

    //Line Graph Model

    //Delcarationts
    public string title;

    

    public string[] dataNames;
    public string[] dataPrefs;

    public Dictionary<string,float>[,] data;

    public int selectedDataName;

    public int selectedDataPreference;
    

    //Saved Models







}


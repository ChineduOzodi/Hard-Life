﻿using UnityEngine;
using System.Collections;
using CodeControl;
using System.Collections.Generic;

public class BarGraphModel : Model
{

    //Line Graph Model

    //Delcarationts
    public string title;

    

    public string[] dataNames;
    public string[] dataPrefs;

    public float[,] data;

    public List<int> selectedDataNames;

    public int selectedDataPreference;
    

    //Saved Models







}


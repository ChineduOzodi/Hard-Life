﻿using UnityEngine;
using System.Collections;
using CodeControl;

public class ToggleButtonModel : Model {


    public string label;

    public string toggleGroupName;

    public bool isToggled;
    public bool addToGroup;

    public int labeID;
}

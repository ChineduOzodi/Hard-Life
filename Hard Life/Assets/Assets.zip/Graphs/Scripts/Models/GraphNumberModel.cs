﻿using UnityEngine;
using System.Collections;
using CodeControl;

public class GraphNumberModel : Model {

    public float height;
    public float width;

    internal string label;
    internal int maxHeight;
}
